===========================================================

              M A G N O L I A (TM)
     Simple Enterprise Content Management

               1. February 2008
             v 3.5.4
               Community Edition

           http://www.magnolia.info/

===========================================================

Magnolia bundled with Tomcat 5.5


Community-powered documentation can be found at:
    http://wiki.magnolia.info

===========================================================
Overview
===========================================================
Welcome to Magnolia 3.5.4

These notes contain information to get you up & running
with Magnolia.

===========================================================
Magnolia Package
===========================================================
The Package contains:

   Apache Tomcat 5.5.25
   magnolia-bundled-webapp 3.5.4
   magnolia-module-workflow 3.5.4


===========================================================
System Requirements
===========================================================

To run Magnolia within the bundled Tomcat, all you need is
a Java SDK, version 1.4.2 or 1.5.
You can get a Java SDK from:
    http://java.sun.com/j2se/1.4.2/download.html (SDK)
    http://java.sun.com/j2se/1.5.0/download.jsp (SDK)
A JRE (Java Runtime Environment) will not be sufficient.

The authoring environment will need a browser. The latest
list of tested and compliant browsers can be found at:
    http://www.magnolia.info


===========================================================
Installation & setup: starting Magnolia
===========================================================

After unzipping or installing, you will have to start
Magnolia:

* Unix (all flavors)

  Open a shell and set the JAVA_HOME environment variable,
  then use the provided magnolia_control.sh script to start
  and stop Tomcat.

  $ export JAVA_HOME=YOUR_JDK_HOME
  $ cd INSTALL_DIRECTORY/apache-tomcat-5.5.25/bin
  $ ./magnolia_control.sh start

  If you used the installer, the magnolia_control.sh script
  has been modified to use the JDK you selected when
  installing, so all you need to do is:

  $ cd INSTALL_DIRECTORY/apache-tomcat-5.5.25/bin
  $ ./magnolia_control.sh start


* Microsoft Windows

  Open a command prompt, and similarly to what you'd do on
  Unix, do:

  > set JAVA_HOME=YOUR_JDK_HOME
  > C:\Program Files\MagnoliaEnterpriseEdition\apache-tomcat-5.5.25\bin\magnolia_control.bat start

  If you used the installer, the magnolia_control.bat
  script has been modified to use the JDK you selected when
  installing, so all you need to do is:

  > C:\Program Files\MagnoliaEnterpriseEdition\apache-tomcat-5.5.25\bin\magnolia_control.bat start

  Alternatively, you can use the shortcuts which have been
  created by the installer.

===========================================================
Connecting to Magnolia
===========================================================

Once Tomcat is started (see above), you can simply point
your browser to 
    http://localhost:8080/
and follow the links on this page to the author and public
instances. (The default "ROOT" tomcat application has been
replaced by a simple page with links to the Magnolia 
instances)
You will have to follow the installation wizard on both
instances before using Magnolia.
The default username & password are:

- username : superuser
- password : superuser

===========================================================
Documentation, Licensing & Support
===========================================================

You can find documentation at:
    http://documentation.magnolia.info/

THIS SOFTWARE IS PROVIDED "AS-IS" AND FREE OF CHARGE, WITH
ABSOLUTELY NO WARRANTY OR SUPPORT OF ANY KIND, EXPRESSED OR
IMPLIED, UNDER THE TERMS OF THE INCLUDED LICENSE AGREEMENT.

Free help is available at the community mailing-list at:
    http://www.magnolia.info/en/developer.html
on a volunteer basis from members of the community and the
Magnolia staff. Please submit help requests and bug reports
concerning our free software distributions to the
mailing-list.

For email and phone support, commercial support packages
are available from Magnolia International. See:
    http://www.magnolia.info/en/services.html
for details on our commercial services regarding Magnolia.


Thank you for using Magnolia.

Magnolia International Ltd.
info@magnolia.info


===========================================================

Copyright 2003-2007 Magnolia International Ltd.

Magnolia is a registered trademark of
Magnolia International Ltd.

http://www.magnolia.info
All rights reserved.
