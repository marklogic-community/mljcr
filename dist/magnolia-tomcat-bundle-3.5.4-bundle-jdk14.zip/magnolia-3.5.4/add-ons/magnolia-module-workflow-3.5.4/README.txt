===========================================================

magnolia-module-workflow 3.5.4

===========================================================

More info about this project can be found at :
    http://documentation.magnolia.info/modules/workflow.html

If an INSTALL.txt file is present in this package, it should
help you getting started.

Change log and known issues can be found on Jira at :
    http://jira.magnolia.info/browse/MAGNOLIA

Community-powered documentation can be found at:
    http://wiki.magnolia.info

